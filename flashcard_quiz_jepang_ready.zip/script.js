const data=[
{jp:'あ',ro:'a'},
{jp:'い',ro:'i'},
{jp:'う',ro:'u'},
{jp:'え',ro:'e'},
{jp:'お',ro:'o'}
];

let score=0;
let time=10;
let timer;
let current;

function start(){
nextQuestion();
startTimer();
}

function startTimer(){
clearInterval(timer);
time=10;
document.getElementById('timer').innerText=time;
timer=setInterval(()=>{
time--;
document.getElementById('timer').innerText=time;
if(time===0){
nextQuestion();
}
},1000);
}

function nextQuestion(){
startTimer();
current=data[Math.floor(Math.random()*data.length)];
document.getElementById('question').innerText=current.jp;
const btns=document.querySelectorAll('.answers button');
btns[0].innerText=current.ro;
btns[1].innerText=data[Math.floor(Math.random()*data.length)].ro;
btns[2].innerText=data[Math.floor(Math.random()*data.length)].ro;
btns[3].innerText=data[Math.floor(Math.random()*data.length)].ro;
}

function answer(isCorrect){
if(isCorrect){
score+=10;
document.getElementById('score').innerText=score;
}
nextQuestion();
}

start();
